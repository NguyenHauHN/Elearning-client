/**
 * Created by haunguyen on 07/03/2018.
 */
var Domain = "https://elearningspm.herokuapp.com";
