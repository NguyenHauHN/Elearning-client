/**
 * Created by haunguyen on 07/03/2018.
 */
var app = angular
  .module('elearningApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'ui.router'
  ]);
app.value("Domain", Domain);
